https://youtu.be/xgQyN54E3ms

Video as the reference.
