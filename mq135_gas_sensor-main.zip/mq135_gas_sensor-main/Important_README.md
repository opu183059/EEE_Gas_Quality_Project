# mq135_gas_sensor

1. use "Link-project-video-reference.md" as reference to build the project.
2. follow proteus diagram to implement the project.
3. You should add the Libraries (Arduino, Gas sensor) before implementing in proteus. Example: https://www.youtube.com/watch?v=TKxAkE3837A
4. Download Arduino IDE from: https://www.arduino.cc/en/guide/windows
5. open "AQlabproject.ino" in the IDE.

Rest is on your hand, THANKS!
